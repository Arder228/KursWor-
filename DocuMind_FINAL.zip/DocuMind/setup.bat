@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 (
    if not exist .runtime mkdir .runtime
    curl.exe -fLsS https://api.nuget.org/v3-flatcontainer/python/3.12.10/python.3.12.10.nupkg -o .runtime\python.zip || exit /b 1
    tar.exe -xf .runtime\python.zip -C .runtime || exit /b 1
    .runtime\tools\python.exe -m venv .venv || exit /b 1
  )
)
.venv\Scripts\python.exe -m pip install -r requirements.txt -c docs\results\environment.txt || exit /b 1
if not exist data\tessdata mkdir data\tessdata
for %%L in (ukr eng) do if not exist data\tessdata\%%L.traineddata (
 curl.exe -fLsS https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/%%L.traineddata -o data\tessdata\%%L.traineddata || exit /b 1
)
.venv\Scripts\python.exe -m pip check
