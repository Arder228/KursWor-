from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from core.store import database
from ui.common import PAGES
from utils.demo import populate


@pytest.fixture(scope="module")
def populated(tmp_path_factory):
    path = tmp_path_factory.mktemp("ui") / "app.duckdb"
    db = database(path)
    populate(db)
    db.close()
    return path


@pytest.mark.parametrize("index", range(len(PAGES)), ids=PAGES)
@pytest.mark.parametrize("has_data", [False, True], ids=["empty", "populated"])
def test_page(index, populated, monkeypatch, has_data, tmp_path):
    import core.store
    import ui.analysis
    from ml.tracking import connect

    monkeypatch.setattr(ui.analysis, "connect", lambda: connect(tmp_path / "tracking"))
    monkeypatch.setattr(
        core.store,
        "database",
        lambda: database(populated if has_data else tmp_path / "empty.duckdb"),
    )
    app = AppTest.from_file(
        str(Path(__file__).resolve().parents[1] / "app.py"), default_timeout=45
    )
    app.query_params["page"] = str(index)
    app.run()
    assert not app.exception and not app.error


def test_edit_and_clean(populated, monkeypatch):
    import core.store

    monkeypatch.setattr(core.store, "database", lambda: database(populated))
    app = AppTest.from_file("app.py", default_timeout=40)
    app.query_params["page"] = "4"
    app.run()
    app.text_area[0].set_value("Перевірка   редагування!")
    app.button[0].click().run()
    assert app.success and not app.exception
    app.query_params["page"] = "5"
    app.run()
    app.button[0].click().run()
    assert app.success and not app.exception
    db = database(populated)
    assert db.sql(
        "select count(*) from staging.processed_texts where cleaned='перевірка редагування'"
    ).fetchone() == (1,)
    db.close()


def test_train_both_and_predict(populated, tmp_path, monkeypatch):
    import core.store
    import ml.service
    import ui.analysis
    from ml.tracking import connect, register

    monkeypatch.setattr(core.store, "database", lambda: database(populated))
    monkeypatch.setattr(ui.analysis, "connect", lambda: connect(tmp_path))
    monkeypatch.setattr(
        ml.service, "register", lambda *args: register(*args, root=tmp_path)
    )
    app = AppTest.from_file("app.py", default_timeout=60)
    for index in (13, 14):
        app.query_params["page"] = str(index)
        app.run()
        app.button[0].click().run()
        assert app.success and not app.exception and not app.error
    app.query_params["page"] = "15"
    app.run()
    app.text_area[0].set_value("Зміни до договору і позову").run()
    app.button[0].click().run()
    assert app.success and not app.exception


def test_export_page_formats(populated, monkeypatch):
    import io
    import json
    import zipfile
    import pandas as pd
    import streamlit as st
    from ui.overview import exports

    db = database(populated)
    outputs = []
    selections = {}

    def choose(label, options, **kwargs):
        return selections.get(label, next(iter(options)))

    def receive(label, data, file_name=None, **kwargs):
        outputs.append((file_name, data))

    monkeypatch.setattr(st, "selectbox", choose)
    monkeypatch.setattr(st, "download_button", receive)
    monkeypatch.setattr(st, "dataframe", lambda *args, **kwargs: None)
    try:
        for material in [
            "Метадані",
            "Класифікація",
            "Теми",
            "Журнал ETL",
            "Походження даних",
            "Датасет",
        ]:
            for fmt in ["csv", "xlsx", "json", "html"]:
                selections.update({"Матеріал": material, "Формат": fmt})
                exports(db)
                filename, blob = outputs.pop()
                assert filename.endswith("." + fmt)
                if fmt == "xlsx":
                    assert len(pd.read_excel(io.BytesIO(blob)).columns) > 0
                elif fmt == "csv":
                    assert len(pd.read_csv(io.BytesIO(blob)).columns) > 0
                elif fmt == "html":
                    assert "<table" in blob.decode()
                else:
                    assert isinstance(json.loads(blob), list)
        for material in ["Каталог DCAT", "Розпізнаний текст", "Експерименти"]:
            selections["Матеріал"] = material
            exports(db)
            filename, blob = outputs.pop()
            if filename.endswith(".jsonld"):
                assert json.loads(blob)["dcat:dataset"][0]["dcat:distribution"]
            elif filename.endswith(".txt"):
                assert blob.strip()
            else:
                with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                    assert archive.testzip() is None and "ocr.csv" in archive.namelist()
    finally:
        db.close()
