import io

import pandas as pd
import pymupdf
import pytest

from core.metadata import dcat, dublin, duplicate_metrics, quality
from core.ocr import METHODS, engine, pages, preprocess, recognize
from core.report import export
from core.store import database, ingest, snapshot, texts
from core.text import clean, errors, frequency
from ml.models import classify, split, topics
from utils.data_generator import corpus, render


@pytest.fixture
def db(tmp_path):
    conn = database(tmp_path / "test.duckdb")
    yield conn
    conn.close()


@pytest.mark.parametrize(
    "name,blob",
    [
        ("bad.pdf", b"NO"),
        ("zero.txt", b""),
        ("foreign.exe", b"test"),
        ("bad.png", b"invalid"),
        ("bad.txt", b"\x00"),
    ],
)
def test_quarantine(db, name, blob):
    assert ingest(db, name, blob)[0] == "Карантин"
    assert db.sql("select count(*) from raw.quarantine").fetchone() == (1,)
    assert db.sql("select count(*) from mart.catalog").fetchone() == (0,)


def test_ingest(db):
    text = "Це   перевірка\nкаталогу"
    status, doc = ingest(db, "текст.txt", text.encode())
    assert status == "Прийнято"
    assert ingest(db, "копія.txt", text.encode()) == ("Дублікат", doc)
    row = db.sql("select * from mart.catalog").df().iloc[0].to_dict()
    assert (
        row["pages"] == 1
        and quality(row)["completeness"] == 1
        and row["author"] is None
    )
    assert dublin(row)["dcterms:title"] == "текст"
    assert texts(db).iloc[0].original == text
    assert db.sql("select count(*) from staging.data_lineage").fetchone()[0] >= 4
    with pytest.raises(Exception):
        db.execute("insert into raw.document_pages values ('відсутній',1,'OCR',50,1)")
    assert "size" in quality({"size": -1})["invalid"]


def test_pdf():
    doc = pymupdf.open()
    doc.new_page().insert_text((20, 30), "Original page")
    doc.new_page()
    rows = list(pages("test.pdf", doc.tobytes()))
    assert "Original" in rows[0][0] and len(rows) == 2 and rows[1][1].size[0] > 0


@pytest.mark.parametrize("method", METHODS)
def test_images(method):
    assert preprocess(render("Перевірка"), method).width > 0


def test_real_ocr(db):
    assert {"ukr", "eng"}.issubset(engine()[1])
    image = render("Перевірка системи")
    val, conf, sec = recognize(image, "ukr")
    assert errors("Перевірка системи", val)["CER"] < 0.3 and sec > 0 and conf > 0
    buf = io.BytesIO()
    image.save(buf, "PNG")
    assert ingest(db, "test.png", buf.getvalue())[0] == "Прийнято"
    assert db.sql("select count(*) from mart.ocr_quality").fetchone() == (1,)


def test_processing():
    assert clean("Це   сло-\nво, ТА текст!") == "слово текст"
    assert errors("abc", "axc")["CER"] == pytest.approx(1 / 3)
    assert errors("а б", "а")["WER"] == 0.5 and errors("", "а")["CER"] is None
    assert frequency(["один два", "два три"], 2)["два два"] == 0


def test_dataset(db):
    f = corpus(30)
    for r in f.itertuples():
        assert (
            ingest(
                db,
                r.source_document_id + ".txt",
                r.text.encode(),
                category=r.category,
                source_id=r.source_document_id,
            )[0]
            == "Прийнято"
        )
    v = snapshot(db, "Набір", texts(db), "original", 16)
    f = db.execute("select * from staging.members where version=?", [v]).df()
    assert not set(f[f.split == "train"].source_document_id) & set(
        f[f.split == "test"].source_document_id
    )
    v2 = snapshot(db, "Набір", texts(db), "original", 16)
    assert v2 != v
    assert (
        len(
            dcat([dict(id=v, name="Набір", version=1)])["dcat:dataset"][0][
                "dcat:distribution"
            ]
        )
        == 2
    )


def test_models():
    f = corpus(100)
    f = pd.concat([f, f], ignore_index=True)
    train = split(f)
    assert not set(f[train].source_document_id) & set(f[~train].source_document_id)
    m, rep, out = classify(f)
    assert len(rep["cv"]) == 3 and sum(map(sum, rep["matrix"])) == len(out)
    model, words, labels, metrics = topics(f.text, 4)
    assert (
        model.transform([f.text.iloc[0]]).shape == (1, 4)
        and len(words) == 4
        and len(labels) == len(f)
    )


def test_scanned_pdf_and_multiframe_tiff(db):
    pic = render("Перевірка системи").convert("RGB")
    for name, fmt in [("scan.pdf", "PDF"), ("scan.tiff", "TIFF")]:
        file = io.BytesIO()
        pic.save(file, fmt, save_all=True, append_images=[pic])
        status, doc = ingest(db, name, file.getvalue())
        assert status == "Прийнято"
        assert db.execute(
            "select count(*) from mart.ocr_quality where doc=?", [doc]
        ).fetchone() == (2,)


def test_tracking(tmp_path):
    import mlflow

    from ml.tracking import register

    f = corpus(50)
    model, rep, _ = classify(f)
    register("DocuMindClassifier", model, {"seed": 1607}, rep["metrics"], rep, tmp_path)
    loaded = mlflow.sklearn.load_model("models:/DocuMindClassifier/1")
    assert loaded.predict(f.text[:1])[0] == model.predict(f.text[:1])[0]


@pytest.mark.parametrize("fmt", ["csv", "xlsx", "json", "html"])
def test_export(fmt):
    data = export(pd.DataFrame({"Назва": ["=SUM(1)", "<script>"]}), fmt)
    assert len(data) > 15
    if fmt == "html":
        assert b"&lt;script&gt;" in data
    if fmt == "xlsx":
        assert pd.read_excel(io.BytesIO(data)).iloc[0, 0] == "'=SUM(1)"


def test_duplicate_metrics(db):
    assert duplicate_metrics(db) == dict(
        uniqueness=None, attempts=0, duplicates=0, duplicate_rate=None
    )
    ingest(db, "invalid.txt", b"")
    assert duplicate_metrics(db)["uniqueness"] is None
    ingest(db, "one.txt", b"catalog")
    assert duplicate_metrics(db)["uniqueness"] == 1
    ingest(db, "copy.txt", b"catalog")
    assert duplicate_metrics(db) == dict(
        uniqueness=1, attempts=3, duplicates=1, duplicate_rate=1 / 3
    )
