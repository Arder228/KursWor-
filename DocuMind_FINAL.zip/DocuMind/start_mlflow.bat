@echo off
cd /d "%~dp0"
set "PATH=%~dp0.venv\Scripts;%PATH%"
if not exist data mkdir data
.venv\Scripts\mlflow.exe ui --backend-store-uri sqlite:///data/tracking.sqlite --host 127.0.0.1 --port 5016


