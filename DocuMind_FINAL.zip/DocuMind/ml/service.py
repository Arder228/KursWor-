from core.store import event, transaction
from ml.models import classify, topics
from ml.tracking import register


def train_version(db, version, frame, topic_count=None):
    params = dict(
        version=version.id,
        seed=int(version.seed),
        representation=version.representation,
    )
    if topic_count is not None:
        name = "DocuMindTopicModel"
        model, words, labels, metrics = topics(
            frame.text, topic_count, int(version.seed)
        )
        details = dict(words=words)
        params["k"] = topic_count
        output = frame.assign(topic=labels)
    else:
        name = "DocuMindClassifier"
        model, details, output = classify(frame, int(version.seed))
        metrics = details["metrics"]
        params["algorithm"] = details["best"]
    run = register(name, model, params, metrics, details)
    with transaction(db):
        for row in frame.itertuples():
            event(db, row.doc, "Формування ознак", run, "TF-IDF")
        for row in output.itertuples():
            if topic_count is not None:
                db.execute(
                    "insert into mart.topic_results values (?,?,?,?)",
                    [run, row.doc, version.id, int(row.topic)],
                )
                event(db, row.doc, "Тематичне моделювання", run)
            else:
                db.execute(
                    "insert into mart.classification_results values (?,?,?,?,?)",
                    [run, row.doc, version.id, row.category, row.prediction],
                )
                event(db, row.doc, "Класифікація", run)
    return run
