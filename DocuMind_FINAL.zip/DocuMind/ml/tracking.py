from pathlib import Path

import mlflow
import mlflow.sklearn

from core.ocr import ROOT


def connect(root=ROOT / "data"):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    mlflow.set_tracking_uri("sqlite:///" + (root / "tracking.sqlite").as_posix())
    client = mlflow.MlflowClient()
    name = "DocuMind"
    experiment = client.get_experiment_by_name(name)
    if experiment is None:
        client.create_experiment(name, artifact_location=(root / "artifacts").as_uri())
    mlflow.set_experiment(name)
    return client


def register(name, model, params, metrics, details, root=ROOT / "data"):
    connect(root)
    with mlflow.start_run(run_name=name) as run:
        mlflow.log_params(params)
        mlflow.log_metrics(metrics)
        mlflow.log_dict(details, "analysis.json")
        mlflow.sklearn.log_model(
            model,
            "model",
            registered_model_name=name,
            pip_requirements=["scikit-learn", "numpy", "scipy"],
        )
        return run.info.run_id
