from itertools import combinations

import numpy as np
from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import (
    StratifiedGroupKFold,
    cross_val_score,
    train_test_split,
)
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from core.text import STOP


def split(frame, seed=1607):
    pairs = frame[["source_document_id", "category"]].drop_duplicates()
    if pairs.source_document_id.duplicated().any():
        raise ValueError("Спільне джерело має суперечливі категорії")
    train, test = train_test_split(
        pairs.source_document_id,
        test_size=0.2,
        random_state=seed,
        stratify=pairs.category,
    )
    return frame.source_document_id.isin(train)


def classify(frame, seed=1607):
    if "split" in frame:
        frame = frame.sort_values(["source_document_id", "text"], kind="stable")
    mask = frame["split"].eq("train") if "split" in frame else split(frame, seed)
    train, test = frame[mask], frame[~mask]
    if set(train.source_document_id) & set(test.source_document_id):
        raise ValueError("Перетин джерел між вибірками")
    folds = min(5, int(train.groupby("category").source_document_id.nunique().min()))
    if folds < 2 or train.category.nunique() < 2 or test.empty:
        raise ValueError("Недостатньо незалежних джерел для перевірки")
    cv = StratifiedGroupKFold(folds, shuffle=True, random_state=seed)
    scores = {}
    models = {}
    for name, est in [
        ("Логістична регресія", LogisticRegression(max_iter=600, random_state=seed)),
        ("Наївний Баєс", MultinomialNB()),
        ("Лінійний SVM", LinearSVC(random_state=seed)),
    ]:
        model = Pipeline(
            [("tfidf", TfidfVectorizer(ngram_range=(1, 2))), ("model", est)]
        )
        scores[name] = float(
            cross_val_score(
                model,
                train.text,
                train.category,
                groups=train.source_document_id,
                cv=cv,
                scoring="f1_macro",
                error_score="raise",
            ).mean()
        )
        models[name] = model
    best = max(scores, key=scores.get)
    model = models[best].fit(train.text, train.category)
    pred = model.predict(test.text)
    labels = sorted(frame.category.unique())
    report = classification_report(
        test.category, pred, labels=labels, output_dict=True, zero_division=0
    )
    metrics = {
        k: report["macro avg"][v]
        for k, v in [
            ("precision_macro", "precision"),
            ("recall_macro", "recall"),
            ("f1_macro", "f1-score"),
        ]
    }
    metrics["accuracy"] = accuracy_score(test.category, pred)
    return (
        model,
        dict(
            best=best,
            cv=scores,
            metrics=metrics,
            classes=labels,
            matrix=confusion_matrix(test.category, pred, labels=labels).tolist(),
            report=report,
        ),
        test.assign(prediction=pred),
    )


def topics(texts, k, seed=1607):
    model = Pipeline(
        [
            ("tfidf", TfidfVectorizer(stop_words=sorted(STOP))),
            (
                "nmf",
                NMF(
                    n_components=k,
                    init="nndsvda",
                    solver="mu",
                    random_state=seed,
                    max_iter=500,
                ),
            ),
        ]
    )
    x = model[0].fit_transform(texts)
    if min(x.shape) < k:
        raise ValueError("Замало документів або термінів для обраної кількості тем")
    weights = model[1].fit_transform(x)
    names = model[0].get_feature_names_out()
    sets = []
    coherence = []
    for comp in model[1].components_:
        indices = np.argsort(-comp)[: min(8, len(names))]
        sets.append({names[i]: float(comp[i]) for i in indices})
        presence = x[:, indices].toarray() > 0
        for a, b in combinations(range(len(indices)), 2):
            joint = np.mean(presence[:, a] & presence[:, b])
            if joint == 0:
                coherence.append(-1.0)
            elif joint < 1:
                coherence.append(
                    float(
                        np.log(joint / (presence[:, a].mean() * presence[:, b].mean()))
                        / -np.log(joint)
                    )
                )
    return (
        model,
        sets,
        weights.argmax(axis=1),
        dict(
            diversity=len(set().union(*sets)) / sum(map(len, sets)),
            npmi=float(np.mean(coherence)) if coherence else 0.0,
        ),
    )
