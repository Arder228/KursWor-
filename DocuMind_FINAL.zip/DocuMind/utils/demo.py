import argparse

import pandas as pd

from core.ocr import ROOT
from core.store import database, ingest, snapshot, texts, versions
from utils.data_generator import corpus


def populate(db):
    for r in corpus(100).itertuples():
        status, detail = ingest(
            db,
            r.source_document_id + ".txt",
            r.text.encode(),
            source_id=r.source_document_id,
            category=r.category,
            source="Генератор",
        )
        if status == "Карантин":
            raise ValueError(detail)
    existing = versions(db)
    if not existing.name.eq("Демонстраційний корпус").any():
        frame = texts(db)
        snapshot(
            db,
            "Демонстраційний корпус",
            frame[frame.source_document_id.isin(corpus(100).source_document_id)],
            "cleaned",
            1607,
        )


def prepare_models(db):
    from ml.service import train_version

    for item in (
        pd.read_csv(ROOT / "demo/manifest.csv")
        .query("file.str.endswith('original.png')", engine="python")
        .itertuples()
    ):
        state, detail = ingest(
            db,
            item.file,
            (ROOT / "demo" / item.file).read_bytes(),
            category=item.category,
            source_id=item.source_document_id,
            source="Генератор",
        )
        if state == "Карантин":
            raise ValueError(detail)
    v = versions(db).query("name == 'Демонстраційний корпус'").iloc[0]
    frame = db.execute(
        "select * from staging.members where version=? order by doc", [v.id]
    ).df()
    for table, k in [("classification_results", None), ("topic_results", 5)]:
        if not db.execute(
            f"select count(*) from mart.{table} where version=?", [v.id]
        ).fetchone()[0]:
            train_version(db, v, frame, k)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", action="store_true")
    db = database()
    populate(db)
    if parser.parse_args().models:
        prepare_models(db)
    db.close()
