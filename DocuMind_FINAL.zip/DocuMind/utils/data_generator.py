import argparse
import hashlib
import random
import textwrap
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

from core.metadata import CATEGORIES

SEED = 1607
DOMAINS = [
    (
        "кафедри|семестру|заліку|курсу|практикуму|факультету",
        "розклад занять|навчальну програму|письмову роботу|індивідуальне завдання",
        "викладач|куратор групи|декан",
    ),
    (
        "депозиту|переказу|кредиту|кошторису|бюджету|рахунку",
        "відсоткову ставку|платіжну вимогу|вартість облігацій|суму внеску",
        "аналітик|бухгалтер|касир",
    ),
    (
        "огляду|аналізу|обстеження|прийому|відділення|стаціонару",
        "температуру тіла|картку огляду|лабораторну пробу|результати спостережень",
        "лаборант|черговий лікар|терапевт",
    ),
    (
        "сервера|алгоритму|інтерфейсу|сховища|модуля|протоколу",
        "версію прошивки|швидкість запиту|резервну копію|пропускну здатність",
        "розробник|адміністратор|інженер",
    ),
    (
        "позову|договору|клопотання|засідання|рішення|провадження",
        "копію ухвали|апеляційну скаргу|вимогу заявника|заяву сторони",
        "представник|секретар суду|адвокат",
    ),
]
FORMS = [
    "Під час перевірки {a} {c} отримав {b}.",
    "У матеріалах щодо {a} описано {b}. Висновок готує {c}.",
    "Робоча група розглянула {b}. За підсумками {a} відповідь надасть {c}.",
    "До завершення {a} слід перевірити {b}. Зауваження зафіксував {c}.",
]
ENDS = [
    "Порівняння з попереднім періодом триватиме ще {} днів.",
    "Наступну перевірку заплановано через {} днів.",
    "Для узгодження залишилося {} робочих днів.",
    "До протоколу додано {} записів.",
]


def corpus(n, seed=SEED):
    rng = random.Random(seed)
    rows = []
    seen = set()
    for i in range(n):
        domain = DOMAINS[i % 5]
        while True:
            a, b, c = [rng.choice(field.split("|")) for field in domain]
            text = (
                rng.choice(FORMS).format(a=a, b=b, c=c)
                + " "
                + rng.choice(ENDS).format(rng.randint(2, 45))
            )
            if text not in seen:
                break
        seen.add(text)
        rows.append(
            dict(
                source_document_id=f"s{seed}-{i:05d}",
                category=CATEGORIES[i % 5],
                text=text,
                sha256=hashlib.sha256(text.encode()).hexdigest(),
            )
        )
    return pd.DataFrame(rows)


def render(text):
    font = ImageFont.truetype("arial.ttf", 24)
    lines = textwrap.wrap(text, 59)
    im = Image.new("L", (850, 50 + 36 * len(lines)), 255)
    ImageDraw.Draw(im).multiline_text(
        (25, 18), "\n".join(lines), font=font, fill=25, spacing=6
    )
    return im


def damage(im, kind, seed):
    if kind == "Шум":
        noise = np.random.default_rng(seed).normal(0, 43, (im.height, im.width))
        return Image.fromarray(np.clip(np.asarray(im) + noise, 0, 255).astype("uint8"))
    if kind == "Розмиття":
        return im.filter(ImageFilter.GaussianBlur(1.6))
    if kind == "Нахил":
        return im.rotate(4, expand=True, fillcolor=255)
    return ImageEnhance.Contrast(im).enhance(0.16)


def generate(out, full=False):
    out.mkdir(parents=True, exist_ok=True)
    for n in (100, 500, 1000):
        corpus(n).to_csv(out / f"documents_{n}.csv", index=False, encoding="utf-8-sig")
    rows = corpus(1000)
    manifest = []
    for i, r in rows.iloc[: None if full else 5].iterrows():
        folder = out / r.source_document_id
        folder.mkdir(exist_ok=True)
        im = render(r.text)
        im.save(folder / "original.png")
        import time

        fixed_date = time.gmtime(946684800)
        im.convert("RGB").save(
            folder / "scan.pdf", creationDate=fixed_date, modDate=fixed_date
        )
        for kind in ("Шум", "Розмиття", "Нахил", "Контраст"):
            damage(im, kind, i).save(folder / (kind + ".png"))
        for file in sorted(folder.iterdir()):
            blob = file.read_bytes()
            manifest.append(
                dict(
                    file=file.relative_to(out).as_posix(),
                    size=len(blob),
                    sha256=hashlib.sha256(blob).hexdigest(),
                    source_document_id=r.source_document_id,
                    category=r.category,
                )
            )
    pd.DataFrame(manifest).to_csv(
        out / "manifest.csv", index=False, encoding="utf-8-sig"
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--full", action="store_true")
    generate(Path("demo"), p.parse_args().full)
