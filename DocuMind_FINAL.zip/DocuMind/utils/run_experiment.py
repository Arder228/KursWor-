import argparse
import json
import platform
from time import perf_counter

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

from core.metadata import quality
from core.ocr import ROOT, engine, preprocess, recognize
from core.store import database, ingest
from core.text import clean, errors
from ml.models import classify, topics
from utils.data_generator import SEED, corpus, damage, generate, render

OUT = ROOT / "docs/results"
KINDS = ["Шум", "Розмиття", "Нахил", "Контраст"]


def experiment(sample=50):
    OUT.mkdir(parents=True, exist_ok=True)
    generate(ROOT / "demo")
    results = []
    pages = []
    topical = []
    comparison = []
    validation = []
    cache = ROOT / "data/ocr_cache"
    cache.mkdir(parents=True, exist_ok=True)
    for n in (100, 500, 1000):
        frame = corpus(n)
        group = frame.groupby("category", group_keys=False).sample(
            n=min(n, sample) // 5, random_state=SEED
        )
        variants = {"Еталон": [], "OCR": [], "Очищений OCR": []}
        for i, r in group.iterrows():
            kind = KINDS[i % 4]
            img = render(r.text)
            noisy = damage(img, kind, i)
            for label, picture in [
                ("Оригінал", img),
                ("Пошкодження", noisy),
                ("Підготовка", preprocess(noisy, "Автоматично")),
            ]:
                key = cache / f"{r.sha256}-{label}-v1.json"
                if key.exists():
                    text, conf, sec = json.loads(key.read_text(encoding="utf8"))
                else:
                    text, conf, sec = recognize(picture, "ukr")
                    key.write_text(json.dumps([text, conf, sec]), encoding="utf8")
                pages.append(
                    dict(
                        n=n,
                        source_document_id=r.source_document_id,
                        condition=label,
                        damage=kind,
                        reference=r.text,
                        observed=text,
                        confidence=conf,
                        seconds=sec,
                        **errors(r.text, text),
                    )
                )
                if label == "Пошкодження":
                    variants["OCR"].append(text)
                    variants["Очищений OCR"].append(clean(text))
            variants["Еталон"].append(r.text)
        for label, values in variants.items():
            _, report, _ = classify(group.assign(text=values))
            comparison.append(
                dict(
                    n=n,
                    sample=len(group),
                    representation=label,
                    model=report["best"],
                    **report["metrics"],
                )
            )
        begin = perf_counter()
        TfidfVectorizer().fit_transform(frame.text)
        feat = perf_counter() - begin
        begin = perf_counter()
        _, rep, _ = classify(frame)
        classifier = perf_counter() - begin
        validation.extend(
            dict(n=n, model=model, f1_cv=score) for model, score in rep["cv"].items()
        )
        for k in (3, 5, 7):
            begin = perf_counter()
            _, words, labels, metrics = topics(frame.text, k)
            topical.append(
                dict(
                    n=n,
                    k=k,
                    seconds=perf_counter() - begin,
                    distribution=json.dumps(np.bincount(labels, minlength=k).tolist()),
                    **metrics,
                )
            )
        db = database(":memory:")
        begin = perf_counter()
        catalog_seconds = 0
        for r in frame.itertuples():
            timers = {}
            state, msg = ingest(
                db,
                r.source_document_id + ".txt",
                r.text.encode(),
                source_id=r.source_document_id,
                category=r.category,
                source="Генератор",
                timings=timers,
            )
            if state != "Прийнято":
                raise RuntimeError(msg)
            catalog_seconds += timers["catalog_s"]
        duration = perf_counter() - begin
        r = frame.iloc[0]
        ingest(db, "повтор.txt", r.text.encode())
        ingest(db, "порожній.txt", b"")
        before, after = db.sql("select * from mart.completeness").fetchone()
        duplicate, rejected = db.sql(
            "select count(*) filter(where status='Дублікат'), count(*) filter(where status='Карантин') from raw.processing_runs"
        ).fetchone()
        check_start = perf_counter()
        checks = [
            quality(row)
            for row in db.sql("select * from mart.catalog").df().to_dict("records")
        ]
        catalog_time = perf_counter() - check_start
        transform_time = db.sql(
            "select sum(transform_s) from raw.processing_runs"
        ).fetchone()[0]
        results.append(
            dict(
                n=n,
                ocr_documents=len(group),
                ocr_seconds=sum(p["seconds"] for p in pages if p["n"] == n),
                etl_seconds=duration,
                transform_seconds=transform_time,
                catalog_read_validate_seconds=catalog_time,
                metadata_violations=sum(
                    len(c["invalid"]) + len(c["missing"]) for c in checks
                ),
                features_seconds=feat,
                classifier_seconds=classifier,
                before=before,
                after=after,
                duplicates=duplicate,
                rejected=rejected,
                **rep["metrics"],
            )
        )
        results[-1]["catalog_seconds"] = catalog_seconds
        db.close()
        for filename, rows in [
            ("scale", results),
            ("ocr", pages),
            ("topics", topical),
            ("classification", comparison),
            ("validation", validation),
        ]:
            pd.DataFrame(rows).to_csv(
                OUT / (filename + ".csv"), index=False, encoding="utf-8-sig"
            )
        print(n, flush=True)
    tables = [
        ("Масштабування", pd.DataFrame(results)),
        (
            "Якість OCR",
            pd.DataFrame(pages)
            .groupby(["n", "condition"])[["CER", "WER", "seconds"]]
            .mean()
            .reset_index(),
        ),
        ("Теми", pd.DataFrame(topical)),
        ("Вплив очищення", pd.DataFrame(comparison)),
    ]
    report = (
        "# Результати вимірювань\n\n"
        + platform.platform()
        + "; Python "
        + platform.python_version()
        + "; "
        + engine()[0]
        + ". Seed 1607. OCR охоплює стратифіковану підвибірку кожного корпусу. Час OCR містить збережені вимірювання повторно використаних сторінок.\n"
    )
    for title, df in tables:
        report += (
            "\n## "
            + title
            + "\n\n"
            + df.to_markdown(index=False, floatfmt=".4f")
            + "\n"
        )
    (OUT / "RESULTS.md").write_text(report, encoding="utf8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample", type=int, default=50)
    experiment(parser.parse_args().sample)
