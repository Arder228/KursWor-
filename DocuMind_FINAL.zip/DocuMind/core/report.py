import io
from html import escape


def export(frame, fmt, title="DocuMind"):
    if fmt == "json":
        return frame.to_json(
            orient="records", force_ascii=False, date_format="iso"
        ).encode()
    if fmt == "html":
        return (
            "<!doctype html><html lang='uk'><meta charset='utf-8'><title>"
            + escape(title)
            + "</title><h1>"
            + escape(title)
            + "</h1>"
            + frame.to_html(index=False, escape=True)
            + "</html>"
        ).encode()
    safe = frame.copy()
    for col in safe.select_dtypes(include=["object", "string"]).columns:
        safe[col] = safe[col].map(
            lambda v: (
                "'" + v
                if isinstance(v, str) and v.startswith(("=", "+", "-", "@", "\t", "\r"))
                else v
            )
        )
    if fmt == "csv":
        return safe.to_csv(index=False).encode("utf-8-sig")
    stream = io.BytesIO()
    safe.to_excel(stream, index=False, engine="openpyxl")
    return stream.getvalue()
