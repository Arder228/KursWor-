import re
from datetime import datetime

from core.ocr import FORMATS

REQUIRED = ["id", "title", "format", "size", "pages", "sha256", "uploaded"]
CATEGORIES = ["Освіта", "Фінанси", "Медицина", "Технології", "Право"]
DC = dict(
    identifier="id",
    title="title",
    creator="author",
    subject="keywords",
    description="description",
    language="language",
    format="format",
    created="created",
    modified="modified",
    source="source",
    rights="rights",
)


def quality(row):
    missing = [k for k in REQUIRED if row.get(k) in (None, "")]
    rules = {
        "size": lambda x: int(x) > 0,
        "pages": lambda x: int(x) > 0,
        "format": lambda x: x in FORMATS,
        "sha256": lambda x: bool(re.fullmatch("[a-f0-9]{64}", x)),
        "uploaded": lambda x: bool(datetime.fromisoformat(str(x))),
    }
    invalid = []
    for k, test in rules.items():
        if k in missing:
            continue
        try:
            valid = test(row[k])
        except (ValueError, TypeError):
            valid = False
        if not valid:
            invalid.append(k)
    return dict(
        completeness=1 - len(missing) / len(REQUIRED),
        validity=1 - len(invalid) / max(1, len(set(rules) - set(missing))),
        missing=missing,
        invalid=invalid,
    )


def duplicate_metrics(db):
    documents, hashes = db.sql(
        "select count(*),count(distinct sha256) from mart.catalog"
    ).fetchone()
    attempts, duplicates = db.sql(
        "select count(*),count(*) filter(where status='Дублікат') from raw.processing_runs"
    ).fetchone()
    return dict(
        uniqueness=hashes / documents if documents else None,
        duplicates=duplicates,
        attempts=attempts,
        duplicate_rate=duplicates / attempts if attempts else None,
    )


def dublin(row):
    return {
        "@context": {"dcterms": "http://purl.org/dc/terms/"},
        **{
            "dcterms:" + k: str(row[v])
            for k, v in DC.items()
            if row.get(v) is not None and str(row[v]).strip()
        },
    }


def dcat(versions):
    return {
        "@context": {
            "dcat": "http://www.w3.org/ns/dcat#",
            "dcterms": "http://purl.org/dc/terms/",
        },
        "@type": "dcat:Catalog",
        "@id": "urn:documind:catalog",
        "dcterms:title": "Каталог DocuMind",
        "dcat:dataset": [
            {
                "@id": "urn:documind:dataset:" + v["id"],
                "@type": "dcat:Dataset",
                "dcterms:title": v["name"],
                "dcat:version": str(v["version"]),
                "dcat:distribution": [
                    {
                        "@type": "dcat:Distribution",
                        "dcterms:format": fmt,
                        "dcterms:title": v["name"] + "." + fmt,
                    }
                    for fmt in ("csv", "xlsx")
                ],
            }
            for v in versions
        ],
    }
