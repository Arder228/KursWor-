import time
from contextlib import contextmanager
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from uuid import uuid4

import duckdb

from core.metadata import CATEGORIES, quality
from core.ocr import ROOT, pages, preprocess, recognize
from core.text import clean, frequency, normalize
from ml.models import split


def uid():
    return uuid4().hex


def database(path=None):
    if path is None:
        (ROOT / "data").mkdir(exist_ok=True)
        path = ROOT / "data/documind.duckdb"
    db = duckdb.connect(str(path))
    db.execute((Path(__file__).with_name("schema.sql")).read_text(encoding="utf8"))
    db.executemany(
        "insert or ignore into staging.categories values (?)",
        [(c,) for c in CATEGORIES],
    )
    return db


@contextmanager
def transaction(db):
    db.execute("begin")
    try:
        yield
        db.execute("commit")
    except Exception:
        db.execute("rollback")
        raise


def event(db, doc, operation, entity, details=""):
    db.execute(
        "insert into staging.data_lineage values (?,?,?,?,?,?,default)",
        [uid(), doc, operation, entity, "1.0", details],
    )


def ingest(
    db,
    name,
    blob,
    lang="ukr",
    method="Оригінал",
    source_id=None,
    category=None,
    source=None,
    progress=None,
    timings=None,
):
    start = time.perf_counter()
    run = uid()
    digest = sha256(blob).hexdigest()
    ext = Path(name).suffix[1:].lower()
    found = db.execute(
        "select id from raw.documents where sha256=?", [digest]
    ).fetchone()
    if found:
        db.execute(
            "insert into raw.processing_runs values (?,?, 'Дублікат',null,?,?,0,0,default)",
            [run, name, found[0], time.perf_counter() - start],
        )
        return "Дублікат", found[0]
    doc = uid()
    try:
        if progress:
            progress(0)
        extracted = []
        for value, image, props in pages(name, blob):
            if time.perf_counter() - start > 120:
                raise ValueError("Перевищено 120 секунд на документ")
            technique = "Текст"
            score = None
            seconds = 0
            if not value.strip() and image is not None:
                value, score, seconds = recognize(preprocess(image, method), lang)
                technique = "OCR"
            extracted.append((value, technique, score, seconds))
        middle = time.perf_counter()
        if progress:
            progress(1)
        text = "\n".join(row[0] for row in extracted)
        processed = clean(text)
        metadata_start = time.perf_counter()
        keywords = ", ".join(k for k, _ in frequency([processed]).most_common(8))
        now = datetime.now()
        title = props.get("title") or Path(name).stem
        base = dict(title=Path(name).stem, format=ext)
        metadata = dict(
            base,
            id=doc,
            title=title,
            sha256=digest,
            size=len(blob),
            pages=len(extracted),
            uploaded=now,
        )
        initial, final = quality(base), quality(metadata)
        if final["invalid"] or final["missing"]:
            raise ValueError(str(final))
        if timings is not None:
            timings["catalog_s"] = time.perf_counter() - metadata_start
        language = lang if any(row[1] == "OCR" for row in extracted) else None
        load = time.perf_counter()
        if progress:
            progress(2)
        with transaction(db):
            db.execute(
                "insert into raw.documents values (?,?,?,?,?,?,?,?)",
                [doc, source_id or digest, name, ext, len(blob), digest, blob, now],
            )
            for page, (value, technique, score, seconds) in enumerate(extracted, 1):
                db.execute(
                    "insert into raw.document_pages values (?,?,?,?,?)",
                    [doc, page, technique, score, seconds],
                )
                db.execute(
                    "insert into raw.raw_texts values (?,?,?)", [doc, page, value]
                )
            metadata_write = time.perf_counter()
            db.execute(
                "insert into staging.document_metadata values (?,?,?,?,?,?,?,?,?,?,default)",
                [
                    doc,
                    title,
                    props.get("author") or None,
                    source,
                    language,
                    category,
                    keywords,
                    props.get("creationDate") or None,
                    None,
                    None,
                ],
            )
            if timings is not None:
                timings["catalog_s"] += time.perf_counter() - metadata_write
            db.execute(
                "insert into staging.processed_texts values (?,null,?,'{}')",
                [doc, processed],
            )
            dims = [
                now.date(),
                language or "Невідомо",
                source or "Невідомо",
                category or "Без категорії",
                ext,
            ]
            for dim, val in zip(
                ("date", "language", "source", "category", "format"), dims
            ):
                db.execute(f"insert or ignore into mart.dim_{dim} values (?)", [val])
            scores = [r[2] for r in extracted if r[2] is not None]
            db.execute(
                "insert into mart.fact_document_processing values (?,?,?,?,?,?,?,?,?,?,?,?)",
                [
                    run,
                    doc,
                    *dims,
                    len(extracted),
                    sum(r[3] for r in extracted),
                    sum(scores) / len(scores) if scores else None,
                    initial["completeness"],
                    final["completeness"],
                ],
            )
            for label in [
                "Файл",
                *(["Підготовка зображення", "OCR"] if language else []),
                "Видобування тексту",
                "Очищення",
                "Каталогізація",
            ]:
                event(
                    db,
                    doc,
                    label,
                    run,
                    method if label == "Підготовка зображення" else "",
                )
            db.execute(
                "insert into raw.processing_runs values (?,?,'Прийнято',null,?,?,?,?,?)",
                [
                    run,
                    name,
                    doc,
                    middle - start,
                    load - middle,
                    time.perf_counter() - load,
                    now,
                ],
            )
        return "Прийнято", doc
    except Exception as exc:
        with transaction(db):
            db.execute(
                "insert into raw.processing_runs values (?,?,'Карантин',?,null,?,0,0,default)",
                [run, name, str(exc), time.perf_counter() - start],
            )
            if len(blob) <= 20 * 1024**2:
                db.execute("insert into raw.quarantine values (?,?)", [run, blob])
        return "Карантин", str(exc)


def texts(db):
    return db.sql("""select c.id as doc,c.title,c.source_document_id,c.category,t.cleaned,t.edited,
    string_agg(r.value,chr(10) order by r.page) as original from mart.catalog c
    join staging.processed_texts t on c.id=t.doc join raw.raw_texts r on r.doc=c.id group by all order by c.title""").df()


def snapshot(db, name, frame, representation, seed):
    if not name.strip() or frame.empty or frame.category.isna().any():
        raise ValueError("Введіть назву й оберіть документи з категоріями")
    data = frame.copy()
    if data[representation].isna().any():
        raise ValueError("Відсутнє вибране текстове представлення")
    data["normalized"] = data[representation].map(normalize)
    if data.normalized.eq("").any():
        raise ValueError("У вибірці є порожні тексти")
    if data.groupby("normalized").category.nunique().gt(1).any():
        raise ValueError("Однакові тексти мають суперечливі категорії")
    data = data.drop_duplicates("normalized").copy()
    data["split"] = split(data, seed).map({True: "train", False: "test"})
    version = uid()
    with transaction(db):
        db.execute(
            "insert or ignore into staging.datasets values (?,?)", [uid(), name.strip()]
        )
        dataset = db.execute(
            "select id from staging.datasets where name=?", [name.strip()]
        ).fetchone()[0]
        number = db.execute(
            "select coalesce(max(version),0)+1 from staging.dataset_versions where dataset=?",
            [dataset],
        ).fetchone()[0]
        db.execute(
            "insert into staging.dataset_versions values (?,?,?,?,?,default)",
            [version, dataset, number, representation, seed],
        )
        for _, r in data.iterrows():
            db.execute(
                "insert into staging.members values (?,?,?,?,?,?)",
                [
                    version,
                    r.doc,
                    r.source_document_id,
                    r.category,
                    r[representation],
                    r["split"],
                ],
            )
            event(db, r.doc, "Додавання до датасету", version)
    return version


def versions(db):
    return db.sql(
        "select v.*, d.name from staging.dataset_versions v join staging.datasets d on d.id=v.dataset order by created desc"
    ).df()
