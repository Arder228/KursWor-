import io
import shutil
import time
from pathlib import Path

import cv2
import numpy as np
import pymupdf
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TESS = ROOT / "data/tessdata"
METHODS = [
    "Оригінал",
    "Автоматично",
    "Відтінки сірого",
    "Otsu",
    "Адаптивний поріг",
    "Шумозаглушення",
    "Контраст",
    "Вирівнювання",
    "Масштабування",
]
FORMATS = ["pdf", "png", "jpg", "jpeg", "tif", "tiff", "txt"]


def engine():
    if shutil.which("tesseract"):
        import pytesseract

        return "Tesseract CLI", pytesseract.get_languages(config="")
    import tesserocr

    return tesserocr.tesseract_version().splitlines()[0], [
        p.stem for p in TESS.glob("*.traineddata")
    ]


def preprocess(image, method):
    if method == METHODS[0]:
        return image
    gray = np.array(image.convert("L"))
    if method in (METHODS[1], METHODS[7]):
        points = np.column_stack(np.where(gray < np.percentile(gray, 25)))[:, ::-1]
        if len(points) > 8:
            angle = cv2.minAreaRect(points.astype("float32"))[-1]
            if angle > 45:
                angle -= 90
            if abs(angle) <= 15:
                h, w = gray.shape
                gray = cv2.warpAffine(
                    gray,
                    cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1),
                    (w, h),
                    borderValue=255,
                )
    if method in (METHODS[1], METHODS[5]):
        gray = cv2.medianBlur(gray, 3)
    if method in (METHODS[1], METHODS[3]):
        gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    if method == METHODS[4]:
        gray = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 8
        )
    if method == METHODS[6]:
        gray = cv2.createCLAHE(2).apply(gray)
    if method == METHODS[8]:
        gray = cv2.resize(gray, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_CUBIC)
    return Image.fromarray(gray)


def recognize(image, language):
    start = time.perf_counter()
    if shutil.which("tesseract"):
        import pytesseract

        data = pytesseract.image_to_data(
            image, lang=language, timeout=30, output_type=pytesseract.Output.DICT
        )
        words = [
            (w, float(c))
            for w, c in zip(data["text"], data["conf"])
            if w.strip() and float(c) >= 0
        ]
        text = " ".join(w for w, c in words)
        confidence = np.mean([c for w, c in words]) if words else None
    else:
        import tesserocr

        with tesserocr.PyTessBaseAPI(
            path=str(TESS), lang=language, psm=tesserocr.PSM.AUTO
        ) as api:
            api.SetImage(image)
            if not api.Recognize(30000):
                raise ValueError("Перевищено час розпізнавання")
            text = api.GetUTF8Text().strip()
            confidence = api.MeanTextConf() if text else None
    return text, confidence, time.perf_counter() - start


def pages(name, blob):
    ext = Path(name).suffix.lower()[1:]
    if not blob or len(blob) > 20 * 1024**2 or ext not in FORMATS:
        raise ValueError("Порожній файл, непідтримуваний формат або перевищено 20 МБ")
    if ext == "txt":
        value = blob.decode("utf-8-sig")
        if not value.strip() or chr(0) in value:
            raise ValueError("Очікується текст UTF-8")
        yield value, None, {}
    elif ext == "pdf":
        with pymupdf.open(stream=blob, filetype="pdf") as pdf:
            if not pdf.is_pdf or pdf.needs_pass or not 1 <= len(pdf) <= 75:
                raise ValueError("Захищений PDF або перевищено ліміт 75 сторінок")
            for page in pdf:
                if page.rect.get_area() * 4 > 12_000_000:
                    raise ValueError("Сторінка перевищує 12 Мп")
                pix = page.get_pixmap(
                    matrix=pymupdf.Matrix(2, 2), colorspace=pymupdf.csRGB
                )
                yield (
                    page.get_text(),
                    Image.frombytes("RGB", (pix.width, pix.height), pix.samples),
                    pdf.metadata or {},
                )
    else:
        with Image.open(io.BytesIO(blob)) as im:
            if (
                im.format
                != {
                    "jpg": "JPEG",
                    "jpeg": "JPEG",
                    "tif": "TIFF",
                    "tiff": "TIFF",
                    "png": "PNG",
                }[ext]
                or im.n_frames > 75
            ):
                raise ValueError("Невідповідний формат або забагато сторінок")
            for i in range(im.n_frames):
                im.seek(i)
                if im.width * im.height > 12_000_000:
                    raise ValueError("Зображення перевищує 12 Мп")
                yield "", im.convert("RGB"), {}
