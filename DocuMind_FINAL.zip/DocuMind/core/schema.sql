CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS staging;
CREATE SCHEMA IF NOT EXISTS mart;
CREATE TABLE IF NOT EXISTS raw.documents(id VARCHAR PRIMARY KEY, source_document_id VARCHAR NOT NULL, filename VARCHAR NOT NULL, format VARCHAR NOT NULL, size BIGINT CHECK(size>0), sha256 VARCHAR UNIQUE NOT NULL, original BLOB NOT NULL, uploaded TIMESTAMP DEFAULT current_timestamp);
CREATE TABLE IF NOT EXISTS raw.document_pages(doc VARCHAR REFERENCES raw.documents(id), page INTEGER CHECK(page>0), method VARCHAR, confidence DOUBLE, seconds DOUBLE, PRIMARY KEY(doc,page));
CREATE TABLE IF NOT EXISTS raw.raw_texts(doc VARCHAR,page INTEGER,value VARCHAR NOT NULL,PRIMARY KEY(doc,page),FOREIGN KEY(doc,page) REFERENCES raw.document_pages(doc,page));
CREATE TABLE IF NOT EXISTS raw.processing_runs(id VARCHAR PRIMARY KEY, filename VARCHAR,status VARCHAR,reason VARCHAR,doc VARCHAR REFERENCES raw.documents(id),extract_s DOUBLE,transform_s DOUBLE,load_s DOUBLE,started TIMESTAMP DEFAULT current_timestamp);
CREATE TABLE IF NOT EXISTS raw.quarantine(run VARCHAR PRIMARY KEY REFERENCES raw.processing_runs(id),original BLOB);
CREATE TABLE IF NOT EXISTS staging.categories(name VARCHAR PRIMARY KEY);
CREATE TABLE IF NOT EXISTS staging.document_metadata(doc VARCHAR PRIMARY KEY,title VARCHAR,author VARCHAR,source VARCHAR,language VARCHAR,category VARCHAR REFERENCES staging.categories(name),keywords VARCHAR,created VARCHAR,description VARCHAR,rights VARCHAR,modified TIMESTAMP DEFAULT current_timestamp);
CREATE TABLE IF NOT EXISTS staging.processed_texts(doc VARCHAR PRIMARY KEY,edited VARCHAR,cleaned VARCHAR,settings VARCHAR);
CREATE TABLE IF NOT EXISTS staging.datasets(id VARCHAR PRIMARY KEY,name VARCHAR UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS staging.dataset_versions(id VARCHAR PRIMARY KEY,dataset VARCHAR REFERENCES staging.datasets(id),version INTEGER,representation VARCHAR,seed INTEGER,created TIMESTAMP DEFAULT current_timestamp,UNIQUE(dataset,version));
CREATE TABLE IF NOT EXISTS staging.members(version VARCHAR REFERENCES staging.dataset_versions(id),doc VARCHAR,source_document_id VARCHAR,category VARCHAR,text VARCHAR,split VARCHAR CHECK(split IN ('train','test')),PRIMARY KEY(version,doc));
CREATE TABLE IF NOT EXISTS staging.data_lineage(id VARCHAR PRIMARY KEY,doc VARCHAR,operation VARCHAR,entity VARCHAR,algorithm VARCHAR,details VARCHAR,stamp TIMESTAMP DEFAULT current_timestamp);
CREATE TABLE IF NOT EXISTS mart.classification_results(run VARCHAR,doc VARCHAR,version VARCHAR,actual VARCHAR,prediction VARCHAR,PRIMARY KEY(run,doc));
CREATE TABLE IF NOT EXISTS mart.topic_results(run VARCHAR,doc VARCHAR,version VARCHAR,topic INTEGER,PRIMARY KEY(run,doc));
CREATE TABLE IF NOT EXISTS mart.dim_date(value DATE PRIMARY KEY);
CREATE TABLE IF NOT EXISTS mart.dim_language(value VARCHAR PRIMARY KEY);
CREATE TABLE IF NOT EXISTS mart.dim_source(value VARCHAR PRIMARY KEY);
CREATE TABLE IF NOT EXISTS mart.dim_category(value VARCHAR PRIMARY KEY);
CREATE TABLE IF NOT EXISTS mart.dim_format(value VARCHAR PRIMARY KEY);
CREATE TABLE IF NOT EXISTS mart.fact_document_processing(run VARCHAR PRIMARY KEY,doc VARCHAR,day DATE REFERENCES mart.dim_date(value),language VARCHAR REFERENCES mart.dim_language(value),source VARCHAR REFERENCES mart.dim_source(value),category VARCHAR REFERENCES mart.dim_category(value),format VARCHAR REFERENCES mart.dim_format(value),pages INTEGER,ocr_s DOUBLE,confidence DOUBLE,before_quality DOUBLE,after_quality DOUBLE);
CREATE OR REPLACE VIEW mart.catalog AS SELECT d.* EXCLUDE(original),m.* EXCLUDE(doc),f.pages,f.ocr_s,f.confidence,f.after_quality,
length(t.cleaned) AS characters,len(string_split(t.cleaned,' ')) AS words,'Оброблено' AS status,
(SELECT string_agg(DISTINCT version,', ') FROM staging.members WHERE doc=d.id) AS versions
FROM raw.documents d JOIN staging.document_metadata m ON d.id=m.doc JOIN staging.processed_texts t ON t.doc=d.id JOIN mart.fact_document_processing f ON f.doc=d.id;
CREATE OR REPLACE VIEW mart.by_category AS SELECT coalesce(category,'Без категорії') AS category,count(*) AS documents FROM mart.catalog GROUP BY 1;
CREATE OR REPLACE VIEW mart.by_format AS SELECT format,count(*) AS documents FROM mart.catalog GROUP BY 1;
CREATE OR REPLACE VIEW mart.processing AS SELECT status,count(*) AS runs,sum(extract_s+transform_s+load_s) AS seconds FROM raw.processing_runs GROUP BY 1;
CREATE OR REPLACE VIEW mart.completeness AS SELECT avg(before_quality) AS initial,avg(after_quality) AS extracted FROM mart.fact_document_processing;
CREATE OR REPLACE VIEW mart.ocr_quality AS SELECT doc,page,confidence,seconds FROM raw.document_pages WHERE method='OCR';
CREATE OR REPLACE VIEW mart.classifications AS SELECT actual,prediction,count(*) AS documents FROM mart.classification_results GROUP BY 1,2;
CREATE OR REPLACE VIEW mart.timeline AS SELECT day,count(*) AS documents,sum(ocr_s) AS ocr_s FROM mart.fact_document_processing GROUP BY 1;
