import re
import unicodedata
from collections import Counter

from rapidfuzz.distance import Levenshtein

STOP = set(
    "і й та у в на до за з із для що це а по від про при або під після також було були як the a an and of to in".split()
)


def normalize(text):
    return " ".join(unicodedata.normalize("NFC", text).split())


def tokens(text):
    return re.findall(r"[^\W_]+(?:[’'-][^\W_]+)*", text.lower(), re.UNICODE)


def clean(text, lower=True, punctuation=True, stop=True):
    value = re.sub(r"(?<=\w)-\r?\n(?=\w)", "", unicodedata.normalize("NFKC", text))
    value = normalize(
        "".join(
            c
            for c in value
            if c.isspace() or not unicodedata.category(c).startswith("C")
        )
    )
    if lower:
        value = value.lower()
    if punctuation:
        value = re.sub(r"[^\w\s’'-]", " ", value)
    return " ".join(w for w in value.split() if not stop or w.lower() not in STOP)


def errors(reference, observed):
    a, b = normalize(reference), normalize(observed)
    if not a:
        return dict(CER=None, WER=None, edits=None)
    count = Levenshtein.distance(a, b)
    return dict(
        CER=count / len(a),
        WER=Levenshtein.distance(a.split(), b.split()) / len(a.split()),
        edits=count,
    )


def frequency(texts, n=1):
    counts = Counter()
    for text in texts:
        words = tokens(text)
        counts.update(" ".join(words[i : i + n]) for i in range(len(words) - n + 1))
    return counts
