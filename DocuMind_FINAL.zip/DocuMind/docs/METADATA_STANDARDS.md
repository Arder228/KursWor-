# Профілі метаданих

Одиницею опису Dublin Core є документ. Каталог показує технічні атрибути окремо від бібліографічних. PDF може містити авторську назву, автора і дату створення. Якщо назва відсутня, використовується основа імені файла. Походження та права заповнює користувач за наявності відомостей.

| Атрибут DocuMind | Термін DCMI |
|---|---|
| id, title | dcterms:identifier, dcterms:title |
| author, keywords | dcterms:creator, dcterms:subject |
| description, language, format | dcterms:description, dcterms:language, dcterms:format |
| created, modified | dcterms:created, dcterms:modified |
| source, rights | dcterms:source, dcterms:rights |

JSON-LD документа пропускає порожні значення. Розширення формату та значення дати PDF подаються в локальному представленні. Реалізовано прикладний профіль. Офіційний словник визначає ширші допустимі описи. [DCMI Metadata Terms](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/)

DCAT-експорт створює dcat:Catalog з локальним URN. Кожна версія набору має стабільний URN, тип dcat:Dataset, назву та dcat:version. Два вузли dcat:Distribution описують доступний експорт CSV і XLSX. Файли створюються через інтерфейс на вимогу. Загальнодоступні URL відсутні. Перевірка структури входить до тестів, формальну SHACL-валідацію зовнішнього профілю не проводили. [DCAT 3](https://www.w3.org/TR/vocab-dcat-3/)

Історія перетворень зберігає документ, операцію, час, версію алгоритму та ідентифікатор пов’язаної сутності. Події дозволяють дослідити походження в дусі моделі сутностей і діяльності PROV. RDF-серіалізацію PROV застосунок не реалізує.
