import streamlit as st

from core.store import database
from ui.analysis import experiments, frequencies, training
from ui.catalog import catalog, lineage, quality_page, warehouse
from ui.common import PAGES, nav
from ui.documents import datasets, editor, library, upload
from ui.overview import efficiency, exports, overview

st.set_page_config(
    page_title="DocuMind · Аналітика документів",
    page_icon="assets/logo.svg",
    layout="wide",
    initial_sidebar_state="collapsed",
)
page = nav()
if page != PAGES[0]:
    st.title(page)
routes = [
    overview,
    efficiency,
    library,
    upload,
    lambda db: editor(db, True),
    lambda db: editor(db, False),
    datasets,
    catalog,
    quality_page,
    lineage,
    lambda db: upload(db, True),
    warehouse,
    frequencies,
    lambda db: training(db, True),
    training,
    experiments,
    exports,
]
db = database()
try:
    routes[PAGES.index(page)](db)
except (ValueError, RuntimeError, OSError) as error:
    st.error("Не вдалося виконати операцію. " + str(error))
finally:
    db.close()
