@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -m utils.demo --models
