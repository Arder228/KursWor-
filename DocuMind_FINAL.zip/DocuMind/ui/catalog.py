import json
from html import escape

import pandas as pd
import plotly.express as px
import streamlit as st

from core.metadata import CATEGORIES, REQUIRED, dublin, duplicate_metrics, quality
from core.store import event, transaction, versions
from ui.common import LABELS, chart, indicators, jsonfile, pick, table


def catalog(db):
    if (
        st.radio("Тип ресурсу", ["Документи", "Датасети"], horizontal=True)
        == "Датасети"
    ):
        resources = versions(db)
        query = st.text_input("Знайти датасет")
        selection = resources[
            resources.name.str.contains(query, case=False, regex=False)
        ]
        table(
            selection.rename(
                columns={
                    "name": "Назва",
                    "version": "Версія",
                    "created": "Створення",
                    "representation": "Представлення",
                }
            ),
            hide_index=True,
        )
        return
    frame = db.sql("select * from mart.catalog").df()
    term = st.text_input("Пошук за назвою, автором, джерелом або ключовими словами")
    a, b, c = st.columns(3)
    formats = a.multiselect("Формати", sorted(frame.format.unique()))
    cats = b.multiselect("Категорії", CATEGORIES)
    order = c.selectbox(
        "Сортування",
        ["title", "uploaded", "size"],
        format_func=lambda k: {"title": "Назва", "uploaded": "Дата", "size": "Розмір"}[
            k
        ],
    )
    mask = (
        frame[["title", "keywords", "author", "source"]]
        .fillna("")
        .astype(str)
        .apply(lambda col: col.str.contains(term, case=False, regex=False))
        .any(axis=1)
    )
    frame = frame[mask]
    if formats:
        frame = frame[frame.format.isin(formats)]
    if cats:
        frame = frame[frame.category.isin(cats)]
    frame = frame.sort_values(order)
    table(frame, hide_index=True)
    r = frame.loc[pick(frame)]
    with st.form("metadata"):
        changes = {
            k: st.text_input(v, r[k] or "")
            for k, v in {
                "title": "Назва",
                "author": "Автор",
                "source": "Джерело",
                "language": "Мова",
                "keywords": "Ключові слова",
                "description": "Опис",
                "rights": "Права",
            }.items()
        }
        changes["category"] = st.selectbox(
            "Категорія документа",
            [None, *CATEGORIES],
            index=([None, *CATEGORIES].index(r.category)),
            format_func=lambda x: x or "Не визначено",
        )
        if st.form_submit_button("Зберегти зміни"):
            if not changes["title"].strip():
                raise ValueError("Назва обов’язкова")
            with transaction(db):
                db.execute(
                    "update staging.document_metadata set "
                    + ",".join(k + "=?" for k in changes)
                    + ",modified=current_timestamp where doc=?",
                    [*(v or None for v in changes.values()), r.id],
                )
                event(
                    db,
                    r.id,
                    "Редагування метаданих",
                    r.id,
                    json.dumps(changes, ensure_ascii=False),
                )
            st.rerun()
    jsonfile("dublin-core.jsonld", dublin(r.dropna().to_dict()))


def quality_page(db):
    stream = duplicate_metrics(db)
    indicators(
        {
            "Унікальність каталогу": f"{stream['uniqueness']:.2%}"
            if stream["uniqueness"] is not None
            else None,
            "Дублікати вхідного потоку": stream["duplicates"],
            "Спроби імпорту": stream["attempts"],
            "Частка повторних спроб": f"{stream['duplicate_rate']:.2%}"
            if stream["duplicate_rate"] is not None
            else None,
        }
    )
    frame = db.sql("select * from mart.catalog").df()
    if frame.empty:
        st.info("Оцінки з’являться після каталогізації.")
        return
    rows = frame.to_dict("records")
    checks = [quality(r) for r in rows]
    scores = {
        "Повнота": sum(c["completeness"] for c in checks) / len(rows),
        "Валідність": sum(c["validity"] for c in checks) / len(rows),
        "Унікальність": stream["uniqueness"],
        "Узгодженість": db.sql(
            "select avg((pages=(select count(*) from raw.document_pages p where p.doc=c.id))::int) from mart.catalog c"
        ).fetchone()[0],
    }
    weights = [st.slider("Вага · " + k, 0, 10, 1) for k in scores]
    if sum(weights):
        st.metric(
            "Інтегральна якість",
            f"{sum(w * s for w, s in zip(weights, scores.values())) / sum(weights):.1%}",
        )
    st.bar_chart(pd.Series(scores), color="#6947D5")
    st.caption(
        "Актуальність залежить від строку перегляду документа. За відсутності такого строку показник не визначено."
    )
    chart(
        px.bar(
            x=[LABELS.get(k, k) for k in REQUIRED],
            y=[
                sum(k not in c["missing"] for c in checks) / len(rows) for k in REQUIRED
            ],
            labels={"x": "Атрибут", "y": "Повнота"},
        )
    )
    table(
        [
            {
                "Назва": r["title"],
                "Відсутні": ", ".join(c["missing"]),
                "Некоректні": ", ".join(c["invalid"]),
            }
            for r, c in zip(rows, checks)
        ],
        hide_index=True,
    )
    table(db.sql("select * from mart.completeness").df())


def lineage(db):
    f = db.sql("select id,title from mart.catalog order by title").df()
    r = f.loc[pick(f)]
    history = db.execute(
        "select stamp,operation,entity,algorithm,details from staging.data_lineage where doc=? order by stamp,rowid",
        [r.id],
    ).df()
    history["Крок"] = range(1, len(history) + 1)
    stages = "".join(
        f"<li><b>{step}. {escape(row.operation)}</b><small>{row.stamp:%d.%m.%Y %H:%M:%S} · Версія {escape(row.algorithm)}</small></li>"
        for step, row in enumerate(history.itertuples(), 1)
    )
    st.html(
        '<ol class="lineage-list" aria-label="Послідовність обробки">'
        + stages
        + "</ol>"
    )
    table(history, hide_index=True)


def warehouse(db):
    tables = db.sql(
        "select table_schema,table_name,table_type from information_schema.tables where table_schema in ('raw','staging','mart') order by 1,2"
    ).df()
    idx = st.selectbox(
        "Таблиця або представлення",
        tables.index,
        format_func=lambda i: ".".join(tables.loc[i, ["table_schema", "table_name"]]),
    )
    table_name = ".".join(tables.loc[idx, ["table_schema", "table_name"]])
    st.metric(
        "Кількість записів", db.sql(f"select count(*) from {table_name}").fetchone()[0]
    )
    table(db.sql("describe " + table_name).df(), hide_index=True)
    columns = db.sql("describe " + table_name).df()
    names = ", ".join(
        '"' + c + '"' for c in columns.loc[columns.column_type != "BLOB", "column_name"]
    )
    table(db.sql(f"select {names} from {table_name} limit 250").df(), hide_index=True)
