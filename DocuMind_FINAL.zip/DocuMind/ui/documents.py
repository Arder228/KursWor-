import json
from hashlib import sha256
from html import escape
from itertools import islice

import pandas as pd
import streamlit as st

from core.metadata import CATEGORIES
from core.ocr import FORMATS, METHODS, ROOT, pages, preprocess, recognize
from core.store import event, ingest, snapshot, texts, transaction, versions
from core.text import clean, errors
from ui.common import difference, document_labels, indicators, pick, table
from utils.data_generator import corpus


def upload(db, pipeline=False):
    if pipeline:
        st.html(
            '<div class="flow"><span>1　Видобування</span><span>2　Перетворення</span><span>3　Завантаження</span></div>'
        )
    files = st.file_uploader(
        "Перетягніть документи сюди", type=FORMATS, accept_multiple_files=True
    )
    if files and st.checkbox("Попередній перегляд"):
        preview = st.selectbox(
            "Файл для перегляду", files, format_func=lambda f: f.name
        )
        try:
            value, image, _ = next(pages(preview.name, preview.getvalue()))
            if image is None:
                st.text(value[:4000])
            else:
                st.image(image, caption="Перша сторінка", width=420)
        except (ValueError, OSError, RuntimeError) as exc:
            st.warning("Попередній перегляд недоступний. " + str(exc))
    a, b, c = st.columns(3)
    lang = a.selectbox("Мова OCR", ["ukr", "eng", "ukr+eng"])
    method = b.selectbox("Підготовка зображень", METHODS)
    category = c.selectbox(
        "Категорія", [None, *CATEGORIES], format_func=lambda x: x or "Не визначено"
    )
    source = st.text_input("Джерело (за наявності)")
    group = st.text_input(
        "Спільний ідентифікатор оригіналу",
        help="Для сканів та копій одного документа використовуйте однаковий ідентифікатор. Для незалежних файлів залиште поле порожнім.",
    )
    if files and st.button("Запустити повний ETL", type="primary"):
        results = []
        bar = st.progress(0)
        stage = st.empty()
        manifest = ROOT / "demo/manifest.csv"
        known = (
            pd.read_csv(manifest).set_index("sha256").to_dict("index")
            if manifest.exists()
            else {}
        )
        labels = ["Видобування", "Перетворення", "Завантаження"]

        def show_stage(index):
            stage.html(
                '<div class="flow">'
                + "".join(
                    "<span>"
                    + ("✓ " if j < index else "● " if j == index else "○ ")
                    + label
                    + "</span>"
                    for j, label in enumerate(labels)
                )
                + "</div>"
            )

        for i, f in enumerate(files):
            blob = f.getvalue()
            record = known.get(sha256(blob).hexdigest(), {})
            status, info = ingest(
                db,
                f.name,
                blob,
                lang,
                method,
                source_id=group.strip() or record.get("source_document_id"),
                category=category or record.get("category"),
                source=source or ("Генератор" if record else None),
                progress=show_stage,
            )
            results.append({"Файл": f.name, "Результат": status, "Подробиці": info})
            bar.progress((i + 1) / len(files), text=f.name + " · " + status)
        table(results)
        stage.empty()
    if not pipeline:
        with st.expander("Демонстраційний корпус"):
            n = st.selectbox("Обсяг корпусу", [100, 500, 1000])
            if st.button("Імпортувати синтетичні тексти"):
                bar = st.progress(0)
                totals = {}
                for i, r in enumerate(corpus(n).itertuples()):
                    status, _ = ingest(
                        db,
                        r.source_document_id + ".txt",
                        r.text.encode(),
                        source_id=r.source_document_id,
                        category=r.category,
                        source="Генератор",
                    )
                    totals[status] = totals.get(status, 0) + 1
                    bar.progress((i + 1) / n)
                indicators(totals)
    else:
        st.subheader("Журнал операцій")
        table(
            db.sql(
                "select * exclude(id) from raw.processing_runs order by started desc"
            ).df(),
            hide_index=True,
        )


def library(db):
    rows = db.sql("select * from mart.catalog order by uploaded desc").df()
    term = st.text_input("Знайти документ")
    rows["label"] = document_labels(rows)
    filtered = rows[
        rows.label.str.contains(term, case=False, regex=False)
        | rows.title.str.contains(term, case=False, regex=False)
    ]
    if filtered.empty:
        st.info("Документів за цим запитом немає.")
        return
    cols = st.columns(3)
    for j, r in enumerate(filtered.itertuples()):
        cols[j % 3].html(
            f'<article class="filecard"><span class="format">{escape(r.format.upper())}</span><b>{escape(r.label)}</b><small>{escape(r.category or "Без категорії")} · {r.pages} стор. · {r.size:,} Б</small></article>'
        )
    row = filtered.loc[pick(filtered)].drop("label")
    st.json(
        json.loads(row.to_json(force_ascii=False, date_format="iso")), expanded=False
    )


def editor(db, ocr):
    frame = texts(db)
    r = frame.loc[pick(frame)]
    current = r.edited if pd.notna(r.edited) else r.original
    if ocr:
        name, blob = db.execute(
            "select filename,original from raw.documents where id=?", [r.doc]
        ).fetchone()
        count = db.execute(
            "select count(*) from raw.document_pages where doc=?", [r.doc]
        ).fetchone()[0]
        page = st.number_input("Сторінка", 1, count)
        embedded, img, _ = next(islice(pages(name, bytes(blob)), page - 1, page))
        a, b = st.columns(2)
        a.subheader("Оригінал")
        key = "edit-" + r.doc
        if img is not None:
            method = a.selectbox("Метод підготовки", METHODS)
            after = preprocess(img, method)
            zoom = a.slider("Масштаб зображень, %", 50, 250, 100, 25)
            a.html(
                f"<style>.st-key-ocr_preview [data-testid=stImage] {{display:block;overflow:auto;width:100%}} .st-key-ocr_preview [data-testid=stImage] img {{width:{zoom}% !important;max-width:none !important;height:auto}}</style>"
            )
            preview = a.container(key="ocr_preview")
            for caption, picture in [("Оригінал", img), ("Після підготовки", after)]:
                preview.caption(caption)
                preview.image(picture, width="stretch")
            lang = a.selectbox("Мова", ["ukr", "eng", "ukr+eng"])
            if a.button("Порівняти OCR сторінки"):
                st.session_state["comparison"] = (
                    r.doc,
                    page,
                    [
                        (label, *recognize(im, lang))
                        for label, im in [
                            ("Оригінал", img),
                            ("Після підготовки", after),
                        ]
                    ],
                )
        else:
            a.text(embedded)
        b.subheader("Текст документа")
        edited = b.text_area("Редагування", current, height=310, key=key)
        if b.button("Зберегти редакцію"):
            with transaction(db):
                db.execute(
                    "update staging.processed_texts set edited=?,cleaned=?,settings='{}' where doc=?",
                    [edited, clean(edited), r.doc],
                )
                event(db, r.doc, "Ручне редагування", r.doc, edited)
            st.success("Редакцію збережено.")
        comp = st.session_state.get("comparison")
        if comp and comp[:2] == (r.doc, page):
            references = ROOT / "demo/documents_1000.csv"
            lookup = (
                pd.read_csv(references).set_index("source_document_id").text
                if references.exists()
                else {}
            )
            ref = st.text_area(
                "Еталон сторінки для CER та WER",
                lookup.get(r.source_document_id, "") if count == 1 else "",
                key=f"ref-{r.doc}-{page}",
            )
            for label, val, score, sec in comp[2]:
                st.markdown("**" + label + "**")
                st.text(val)
                indicators(
                    {
                        "Впевненість": score,
                        "Секунди": sec,
                        **(
                            errors(ref, val)
                            if ref
                            else {"CER / WER": "Недостатньо даних"}
                        ),
                    }
                )
                if ref:
                    difference(ref, val)
    else:
        a, b, c = st.columns(3)
        args = dict(
            lower=a.checkbox("Нижній регістр", True),
            punctuation=b.checkbox("Очистити пунктуацію", True),
            stop=c.checkbox("Вилучити стоп-слова", True),
        )
        result = clean(current, **args)
        difference(current, result)
        st.text_area("NLP-представлення", result, disabled=True)
        if st.button("Зберегти очищений текст"):
            with transaction(db):
                db.execute(
                    "update staging.processed_texts set cleaned=?,settings=? where doc=?",
                    [result, json.dumps(args), r.doc],
                )
                event(db, r.doc, "Очищення", r.doc, json.dumps(args))
            st.success("Збережено")


def datasets(db):
    frame = texts(db)
    table(versions(db), hide_index=True)
    name = st.text_input("Назва датасету")
    cats = st.multiselect("Категорії", CATEGORIES, default=CATEGORIES)
    frame = frame[frame.category.isin(cats)]
    ids = st.multiselect(
        "Документи (порожній вибір включає всі відфільтровані)",
        frame.doc,
        format_func=lambda v: frame.set_index("doc").at[v, "title"],
    )
    if ids:
        frame = frame[frame.doc.isin(ids)]
    if not frame.empty:
        st.bar_chart(frame.category.value_counts(), color="#6947D5")
    rep = st.selectbox(
        "Представлення",
        ["cleaned", "original", "edited"],
        format_func=lambda x: {
            "cleaned": "Очищене",
            "original": "Оригінальне",
            "edited": "Редаговане",
        }[x],
    )
    seed = st.number_input("Зерно генератора", 0, 2147483647, 1607)
    if st.button("Створити версію", type="primary"):
        st.success("Створено версію " + snapshot(db, name, frame, rep, seed))

