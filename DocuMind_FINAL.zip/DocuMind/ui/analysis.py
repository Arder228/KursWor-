import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from wordcloud import WordCloud

from core.store import texts
from core.text import clean, frequency, tokens
from ml.service import train_version
from ml.tracking import connect
from ui.common import chart, indicators, table, version


def frequencies(db):
    scope = st.selectbox("Корпус", ["Бібліотека", "Версія датасету"])
    if scope == "Версія датасету":
        _, f = version(db)
        col = "text"
    else:
        f = texts(db)
        col = st.selectbox(
            "Представлення",
            ["original", "cleaned", "edited"],
            format_func=lambda x: {
                "original": "Вихідний текст",
                "cleaned": "Очищений текст",
                "edited": "Редагований текст",
            }[x],
        )
    cats = st.multiselect("Фільтр категорій", f.category.dropna().unique())
    if cats:
        f = f[f.category.isin(cats)]
    ids = st.multiselect("Фільтр документів", f.doc)
    if ids:
        f = f[f.doc.isin(ids)]
    values = f[col].dropna().tolist()
    counts = frequency(values)
    if not counts:
        st.info("Корпус не містить слів для аналізу.")
        return
    total = sum(counts.values())
    indicators(
        {
            "Слів": total,
            "Символів": sum(map(len, values)),
            "Унікальних слів": len(counts),
            "Слів на документ": round(total / len(values), 2),
            "Символів на слово": round(
                sum(len(w) * n for w, n in counts.items()) / total, 2
            ),
        }
    )
    n = st.radio("Довжина n-грами", [1, 2, 3], horizontal=True)
    top = pd.DataFrame(
        frequency(values, n).most_common(20), columns=["Термін", "Частота"]
    )
    chart(px.bar(top, x="Частота", y="Термін", orientation="h"))
    cloud = WordCloud(
        font_path="C:/Windows/Fonts/arial.ttf",
        width=980,
        height=360,
        background_color="white",
        random_state=1607,
        max_words=60,
    ).generate_from_frequencies(counts)
    fig = go.Figure()
    for (word, weight), size, (row, colx), angle, _ in cloud.layout_:
        fig.add_trace(
            go.Scatter(
                x=[colx],
                y=[-row],
                text=[word],
                mode="text",
                textfont=dict(size=max(10, size * 0.66), color="#6947D5"),
                hovertemplate=f"{word} · {counts[word]}<extra></extra>",
                showlegend=False,
            )
        )
    fig.update_xaxes(visible=False, range=[-80, 1020])
    fig.update_yaxes(visible=False, range=[-390, 25])
    chart(fig)
    st.bar_chart(
        f.assign(Слова=f[col].fillna("").map(lambda x: len(tokens(x))))
        .groupby("category")
        .Слова.sum(),
        color="#6947D5",
    )
    if scope == "Бібліотека":
        table(
            pd.DataFrame(
                {
                    s: pd.Series(frequency(f[v].dropna()))
                    for s, v in [
                        ("До очищення", "original"),
                        ("Після очищення", "cleaned"),
                    ]
                }
            )
            .fillna(0)
            .sort_values("До очищення", ascending=False)
            .head(20)
        )


def training(db, topic=False):
    v, frame = version(db)
    k = st.slider("Кількість тем", 2, 15, 5) if topic else None
    if st.button("Навчити й зареєструвати модель", type="primary"):
        with st.spinner("Навчання та реєстрація в MLflow…"):
            train_version(db, v, frame, k)
            st.success("Модель зареєстровано")
    table_name = "topic_results" if topic else "classification_results"
    result = db.execute(f"select * from mart.{table_name} where version=?", [v.id]).df()
    if result.empty:
        return
    run = st.selectbox("Запуск", list(reversed(result.run.unique())))
    client = connect()
    import mlflow

    detail = mlflow.artifacts.load_dict(f"runs:/{run}/analysis.json")
    result = result[result.run == run]
    if topic:
        chart(
            px.bar(
                result.topic.value_counts()
                .rename_axis("Тема")
                .reset_index(name="Документи"),
                x="Тема",
                y="Документи",
            )
        )
        for i, words in enumerate(detail["words"]):
            with st.expander(f"Тема {i + 1} · " + ", ".join(list(words)[:3])):
                st.bar_chart(pd.Series(words), color="#6947D5")
                table(
                    frame[frame.doc.isin(result[result.topic == i].doc)][
                        ["doc", "text"]
                    ]
                )
        indicators(client.get_run(run).data.metrics)
    else:
        indicators(detail["metrics"])
        chart(
            px.bar(
                x=list(detail["cv"]),
                y=list(detail["cv"].values()),
                labels={"x": "Модель", "y": "F1 Macro · валідація"},
            )
        )
        chart(
            px.imshow(
                detail["matrix"],
                x=detail["classes"],
                y=detail["classes"],
                text_auto=True,
                color_continuous_scale="Purples",
                labels={"x": "Прогноз", "y": "Еталон"},
            )
        )
        table(
            pd.DataFrame(detail["report"]).T.rename(
                index={
                    "macro avg": "Макросереднє",
                    "weighted avg": "Зважене середнє",
                    "accuracy": "Частка правильних прогнозів",
                }
            )
        )
        st.subheader("Помилки класифікації")
        mistakes = result[result.actual != result.prediction]
        if mistakes.empty:
            st.info("Помилок класифікації не виявлено")
        else:
            table(mistakes, hide_index=True)
        table(result)


def experiments(db):
    import mlflow

    client = connect()
    exp = client.get_experiment_by_name("DocuMind")
    table(mlflow.search_runs([exp.experiment_id]), hide_index=True)
    regs = client.search_model_versions()
    if not regs:
        st.info("Після навчання тут з’являться версії моделей.")
        return
    idx = st.selectbox(
        "Зареєстрована версія",
        range(len(regs)),
        format_func=lambda i: f"{regs[i].name} · v{regs[i].version}",
    )
    v = regs[idx]
    f = texts(db)
    selected = st.selectbox(
        "Документ для прогнозу",
        [None, *f.doc],
        format_func=lambda i: (
            "Ввести текст" if i is None else f.set_index("doc").at[i, "title"]
        ),
    )
    rep = client.get_run(v.run_id).data.params.get("representation", "cleaned")
    val = st.text_area(
        "Текст", (f.set_index("doc").at[selected, rep] or "") if selected else ""
    )
    if val.strip() and st.button("Застосувати версію"):
        if not selected and rep == "cleaned":
            val = clean(val)
        model = mlflow.sklearn.load_model(f"models:/{v.name}/{v.version}")
        if model[0].transform([val]).nnz == 0:
            st.warning("У тексті немає термінів зі словника цієї моделі.")
            return
        pred = (
            model.predict([val])[0]
            if v.name == "DocuMindClassifier"
            else int(model.transform([val]).argmax()) + 1
        )
        st.success(str(pred))
