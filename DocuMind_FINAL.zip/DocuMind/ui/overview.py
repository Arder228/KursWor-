import io
import zipfile
from html import escape

import pandas as pd
import plotly.express as px
import streamlit as st

from core.metadata import dcat
from core.ocr import ROOT, engine
from core.report import export
from core.store import texts, versions
from ui.common import (
    LABELS,
    chart,
    document_labels,
    jsonfile,
    pick,
    table,
    tiles,
    version,
)


def overview(db):
    st.html(
        '<section class="hero"><h1>Робочий простір документів</h1><p>Вітаємо у DocuMind. Розпізнавайте сторінки, досліджуйте корпус і простежуйте історію кожного документа.</p><div class="sheets"></div></section>'
    )
    n, pages, quality = db.sql(
        "select count(*),coalesce(sum(pages),0),avg(after_quality) from mart.catalog"
    ).fetchone()
    ds = db.sql("select count(*) from staging.datasets").fetchone()[0]
    topics = db.sql(
        "select count(distinct (run,topic)) from mart.topic_results"
    ).fetchone()[0]
    tiles(
        [
            ("▤", n, "Документів"),
            ("▱", int(pages), "Оброблених сторінок"),
            (
                "✓",
                f"{quality:.0%}" if quality is not None else "—",
                "Повнота метаданих",
            ),
            ("▦", ds, "Датасетів"),
            ("◈", topics, "Тем у запусках"),
        ]
    )
    a, b = st.columns([3, 2])
    with a.container(border=True):
        st.subheader("Останні документи")
        f = db.sql(
            "select id,title,format,pages from mart.catalog order by uploaded desc limit 5"
        ).df()
        if f.empty:
            st.info("Додайте перший документ або імпортуйте демонстраційний корпус.")
        for r in f.assign(label=document_labels(f)).itertuples():
            st.html(
                f'<div class="filecard recent"><span class="format">{escape(r.format.upper())}</span><b>{escape(r.label)}</b><small>{r.pages} стор.</small></div>'
            )
        st.markdown(
            "[Завантажити документи →](?page=3)　 [Відкрити бібліотеку →](?page=2)"
        )
    with b.container(border=True):
        st.subheader("Розподіл за категоріями")
        f = db.sql("select * from mart.by_category").df()
        if len(f):
            chart(px.pie(f, names="category", values="documents", hole=0.58))
        else:
            st.caption("Розподіл з’явиться після завантаження документів.")
        try:
            name, langs = engine()
            st.caption(name + " · " + (", ".join(langs) or "Мовні пакети відсутні"))
        except Exception as e:
            st.warning(str(e))
        st.caption(
            "DuckDB · "
            + str((ROOT / "data/documind.duckdb").stat().st_size // 1024)
            + " КБ"
        )
    st.subheader("Останні операції")
    table(
        db.sql(
            "select filename as Файл,status as Статус,started as Час from raw.processing_runs order by started desc limit 8"
        ).df(),
        hide_index=True,
    )
    table(
        db.sql(
            "select count(*) as Сторінки_OCR,avg(seconds) as Середній_час,avg(confidence) as Впевненість from mart.ocr_quality"
        ).df(),
        hide_index=True,
    )


def efficiency(db):
    st.subheader("Поточне сховище")
    table(db.sql("select * from mart.processing").df(), hide_index=True)
    folder = ROOT / "docs/results"
    if not (folder / "scale.csv").exists():
        st.info("Для порівняння корпусів потрібен запуск експериментів.")
        return
    scale = pd.read_csv(folder / "scale.csv")
    ocr = pd.read_csv(folder / "ocr.csv")
    clf = pd.read_csv(folder / "classification.csv")
    sizes = sorted(scale.n.unique())
    samples = scale.ocr_documents.unique()
    if len(samples) == 1:
        st.caption(
            f"Для OCR у кожному корпусі досліджено {samples[0]} документів. Час ETL охоплює весь корпус."
        )

    def comparison_plot(title, frame, series, group, y_label, lines=False):
        st.subheader(title)
        data = frame.copy()
        data["n"] = data.n.astype(str)
        plot = px.line if lines else px.bar
        options = {"markers": True} if lines else {"barmode": "group"}
        fig = plot(
            data,
            x="n",
            y=series,
            color=group,
            labels={**LABELS, "value": y_label, "variable": "Показник", series: y_label}
            if isinstance(series, str)
            else {**LABELS, "value": y_label, "variable": "Показник"},
            **options,
        )
        fig.update_xaxes(
            type="category",
            categoryorder="array",
            categoryarray=list(map(str, sizes)),
            tickmode="array",
            tickvals=list(map(str, sizes)),
            ticktext=list(map(str, sizes)),
        )
        chart(fig)

    wide = scale.rename(
        columns={
            k: LABELS[k]
            for k in (
                "before",
                "after",
                "etl_seconds",
                "features_seconds",
                "classifier_seconds",
                "ocr_seconds",
            )
        }
    )
    comparison_plot(
        "Повнота метаданих до та після видобування",
        wide,
        [LABELS["before"], LABELS["after"]],
        None,
        "Частка заповнених полів",
    )
    comparison_plot(
        "Тривалість обробки за розміром корпусу",
        wide,
        [
            LABELS[k]
            for k in (
                "etl_seconds",
                "features_seconds",
                "classifier_seconds",
                "ocr_seconds",
            )
        ],
        None,
        "Час, с",
        True,
    )
    comparison_plot(
        "Середня частота символьних помилок OCR",
        ocr.groupby(["n", "condition"], as_index=False).CER.mean(),
        "CER",
        "condition",
        "Частка помилок (CER)",
        True,
    )
    comparison_plot(
        "Вплив очищення тексту на класифікацію",
        clf,
        "f1_macro",
        "representation",
        "F1 (макро)",
    )
    comparison = folder / "validation.csv"
    if comparison.exists():
        comparison_plot(
            "Порівняння класифікаторів на валідації",
            pd.read_csv(comparison),
            "f1_cv",
            "model",
            "Валідаційна F1 (макро)",
        )
    table(scale)
    for r in scale.itertuples():
        st.write(
            f"Корпус із {r.n} документів пройшов ETL за {r.etl_seconds:.2f} с. Повнота зросла з {r.before:.1%} до {r.after:.1%}. OCR охопив {r.ocr_documents} джерел."
        )


def exports(db):
    choices = {
        "Метадані": "mart.catalog",
        "Класифікація": "mart.classification_results",
        "Теми": "mart.topic_results",
        "Журнал ETL": "raw.processing_runs",
        "Походження даних": "staging.data_lineage",
    }
    choice = st.selectbox(
        "Матеріал",
        [*choices, "Датасет", "Розпізнаний текст", "Каталог DCAT", "Експерименти"],
    )
    if choice == "Каталог DCAT":
        jsonfile("catalog.jsonld", dcat(versions(db).to_dict("records")))
    elif choice == "Розпізнаний текст":
        f = texts(db)
        r = f.loc[pick(f)]
        st.download_button(
            "Завантажити TXT",
            r.edited if pd.notna(r.edited) else r.original,
            "document.txt",
        )
    elif choice == "Експерименти":
        files = list((ROOT / "docs/results").glob("*.csv"))
        if files:
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for file in files:
                    z.write(file, file.name)
            st.download_button(
                "Завантажити вимірювання", buf.getvalue(), "experiments.zip"
            )
    else:
        f = (
            version(db)[1]
            if choice == "Датасет"
            else db.sql("select * from " + choices[choice]).df()
        )
        fmt = st.selectbox("Формат", ["csv", "xlsx", "json", "html"])
        table(f.head(50), hide_index=True)
        st.download_button(
            "Завантажити " + fmt.upper(), export(f, fmt, choice), "documind." + fmt
        )
