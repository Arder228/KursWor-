import json
from base64 import b64encode
from difflib import SequenceMatcher
from html import escape

import plotly.express as px
import streamlit as st

from core.ocr import ROOT
from core.store import versions

GROUPS = {
    "Огляд": ["Головна", "Оцінювання ефективності"],
    "Документи": [
        "Бібліотека документів",
        "Завантаження документів",
        "Розпізнавання тексту OCR",
        "Очищення текстів",
        "Підготовка датасетів",
    ],
    "Каталог": ["Каталог метаданих", "Якість метаданих", "Походження даних"],
    "Інженерія даних": ["ETL-пайплайн", "Сховище даних"],
    "Аналітика": ["Частотний аналіз", "Тематичне моделювання"],
    "Машинне навчання": ["Класифікація документів", "ML-експерименти"],
    "Експорт": ["Експорт результатів"],
}
PAGES = sum(GROUPS.values(), [])
COLORS = ["#6947D5", "#A78BFA", "#8D72CA", "#D5C4F8", "#4A367C"]
px.defaults.color_discrete_sequence = COLORS


LABELS = {
    "id": "Ідентифікатор",
    "doc": "Документ",
    "source_document_id": "Первинний документ",
    "source": "Джерело",
    "title": "Назва",
    "name": "Назва набору",
    "format": "Формат",
    "pages": "Сторінки",
    "size": "Розмір, Б",
    "uploaded": "Завантаження",
    "filename": "Файл",
    "author": "Автор",
    "language": "Мова",
    "category": "Категорія",
    "keywords": "Ключові слова",
    "created": "Створено",
    "modified": "Оновлено",
    "rights": "Права",
    "description": "Опис",
    "status": "Статус",
    "reason": "Причина",
    "started": "Початок",
    "algorithm": "Алгоритм",
    "stamp": "Час",
    "operation": "Етап",
    "entity": "Пов’язана сутність",
    "details": "Подробиці",
    "run": "Запуск",
    "version": "Версія",
    "versions": "Версії",
    "text": "Текст",
    "dataset": "Набір",
    "seed": "Зерно генератора",
    "representation": "Представлення",
    "split": "Частина вибірки",
    "prediction": "Прогноз",
    "actual": "Еталон",
    "topic": "Тема",
    "words": "Слова",
    "characters": "Символи",
    "runs": "Спроби",
    "seconds": "Час, с",
    "confidence": "Впевненість",
    "ocr_s": "Час OCR, с",
    "after_quality": "Повнота",
    "extract_s": "Видобування, с",
    "transform_s": "Перетворення, с",
    "load_s": "Завантаження, с",
    "initial": "До обробки",
    "extracted": "Після обробки",
    "before": "До видобування",
    "after": "Після видобування",
    "n": "Розмір корпусу, документів",
    "ocr_documents": "Документи з OCR",
    "duplicates": "Дублікати",
    "rejected": "Відхилено",
    "etl_seconds": "Повний ETL",
    "features_seconds": "Формування ознак",
    "classifier_seconds": "Навчання класифікатора",
    "ocr_seconds": "Розпізнавання OCR",
    "catalog_seconds": "Каталогізація, с",
    "transform_seconds": "Перетворення, с",
    "catalog_read_validate_seconds": "Перевірка каталогу, с",
    "metadata_violations": "Порушення правил",
    "precision": "Точність прогнозів",
    "recall": "Повнота виявлення",
    "support": "Кількість прикладів",
    "f1-score": "F1",
    "accuracy": "Частка правильних прогнозів",
    "precision_macro": "Точність (макро)",
    "recall_macro": "Повнота (макро)",
    "f1_macro": "F1 (макро)",
    "npmi": "Узгодженість (NPMI)",
    "diversity": "Різноманітність тем",
    "edits": "Кількість виправлень",
    "condition": "Стан зображення",
    "model": "Модель",
    "run_id": "Ідентифікатор запуску",
    "experiment_id": "Експеримент",
    "artifact_uri": "Адреса артефактів",
    "start_time": "Початок",
    "end_time": "Завершення",
    "column_name": "Стовпець",
    "column_type": "Тип даних",
    "null": "Допускає NULL",
    "key": "Ключ",
    "default": "Типове значення",
}


def table(data, **kwargs):
    config = {k: v for k, v in LABELS.items()}
    st.dataframe(
        data.round(4) if hasattr(data, "columns") else data,
        column_config=config,
        **kwargs,
    )


def indicators(values):
    from numbers import Integral, Real

    items = []
    for label, value in values.items():
        if value is None:
            display = "Недостатньо даних"
        elif isinstance(value, Real) and not isinstance(value, Integral):
            display = f"{value:.4f}".replace(".", ",")
        else:
            display = str(value)
        items.append(("", escape(display), escape(LABELS.get(label, label))))
    tiles(items)


def document_labels(frame):
    ids = frame["id"] if "id" in frame else frame["doc"]
    titles = frame.title.replace({"original": "Оригінал", "scan": "Скан"})
    labels = titles + " · " + ids.str[:8]
    repeated = labels.duplicated(keep=False)
    labels.loc[repeated] = titles.loc[repeated] + " · " + ids.loc[repeated]
    return labels


def nav():
    idx = st.query_params.get("page", "0")
    page = PAGES[int(idx)] if idx in map(str, range(len(PAGES))) else PAGES[0]
    group = next(g for g, items in GROUPS.items() if page in items)
    logo = b64encode((ROOT / "assets/logo.svg").read_bytes()).decode()
    st.html(
        "<style>" + (ROOT / "assets/style.css").read_text(encoding="utf8") + "</style>"
    )
    st.html(
        f'<div class="brand"><img alt="" src="data:image/svg+xml;base64,{logo}"><strong>DocuMind</strong><small>OCR &amp; Metadata Intelligence</small><span class="local">● Локальна система</span></div>'
    )

    def link(label, target, active):
        return f'<a target="_self" class="{("on" if active else "")}" href="?page={PAGES.index(target)}">{label}</a>'

    st.markdown(
        '<nav class="nav">'
        + "".join(link(g, v[0], g == group) for g, v in GROUPS.items())
        + '</nav><nav class="sub">'
        + "".join(link(v, v, v == page) for v in GROUPS[group])
        + "</nav>",
        unsafe_allow_html=True,
    )
    return page


def tiles(items):
    st.html(
        '<div class="tiles">'
        + "".join(
            f'<div class="tile"><em>{icon}</em><strong>{value}</strong><small>{label}</small></div>'
            for icon, value, label in items
        )
        + "</div>"
    )


def pick(frame, key="doc"):
    if frame.empty:
        st.info("Бібліотека порожня. Додайте файли на сторінці завантаження.")
        st.stop()
    labels = document_labels(frame)
    return st.selectbox(
        "Документ", frame.index, format_func=labels.at.__getitem__, key=key
    )


def version(db):
    vs = versions(db)
    if vs.empty:
        st.info("Створіть версію на сторінці «Підготовка датасетів».")
        st.stop()
    ix = st.selectbox(
        "Версія датасету",
        vs.index,
        format_func=lambda i: f"{vs.loc[i, 'name']} · v{vs.loc[i, 'version']}",
    )
    v = vs.iloc[ix]
    return v, db.execute(
        "select * from staging.members where version=? order by doc", [v.id]
    ).df()


def difference(a, b):
    x, y = a.split(), b.split()
    parts = []
    for op, i, j, k, l in SequenceMatcher(None, x, y).get_opcodes():
        if op == "equal":
            parts.append(escape(" ".join(x[i:j])))
        if op in ("replace", "delete"):
            parts.append("<del>" + escape(" ".join(x[i:j])) + "</del>")
        if op in ("replace", "insert"):
            parts.append("<ins>" + escape(" ".join(y[k:l])) + "</ins>")
    st.html("<p>" + " ".join(parts) + "</p>")


def chart(fig):
    fig.update_layout(
        template="plotly_white",
        colorway=COLORS,
        piecolorway=COLORS,
        legend=dict(orientation="h", yanchor="top", y=-0.22),
        margin=dict(l=15, r=15, t=20, b=20),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font_color="#52496a",
    )
    fig.update_traces(selector=dict(type="pie"), marker=dict(colors=COLORS))
    fig.update_xaxes(automargin=True)
    fig.update_yaxes(automargin=True)
    st.plotly_chart(fig, width="stretch", theme=None)


def jsonfile(name, data):
    st.download_button(
        name,
        json.dumps(data, ensure_ascii=False, indent=2, default=str),
        file_name=name,
        mime="application/ld+json",
    )
